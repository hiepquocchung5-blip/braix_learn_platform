<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// index.php
require_once 'includes/config.php';

// If user is already logged in, redirect to dashboard
if (is_logged_in()) {
    redirect('dashboard.php');
}

// Handle Telegram Login Callback
// This is a simplified example. A full implementation requires
// verifying the Telegram data hash for security.
if (isset($_GET['id']) && isset($_GET['first_name']) && isset($_GET['username']) && isset($_GET['auth_date']) && isset($_GET['hash'])) {
    $telegram_id = sanitize_input($_GET['id']);
    $username = sanitize_input($_GET['username']);
    $first_name = sanitize_input($_GET['first_name']);

    // In a real application, you MUST verify the hash to prevent spoofing.
    // Example (simplified, do not use in production without full verification):
    // $data_check_arr = [];
    // foreach ($_GET as $key => $value) {
    //     if ($key !== 'hash' && $key !== 'auth_date') { // auth_date is also not part of the hash string
    //         $data_check_arr[] = $key . '=' . $value;
    //     }
    // }
    // sort($data_check_arr);
    // $data_check_string = implode("\n", $data_check_arr);
    // $secret_key = hash('sha256', TELEGRAM_BOT_TOKEN, true);
    // $check_hash = hash_hmac('sha256', $data_check_string, $secret_key);
    // if ($check_hash !== $_GET['hash']) {
    //     // Invalid hash, do not log in
    //     echo "<script>alert('Telegram login failed: Invalid data hash.');</script>";
    //     redirect('index.php');
    // }

    // Check if user exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE telegram_id = ?");
    $stmt->bind_param("s", $telegram_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // User exists, log them in
        $user = $result->fetch_assoc();
        $_SESSION['user_id'] = $user['id'];
        redirect('dashboard.php');
    } else {
        // New user, register them
        $stmt_insert = $conn->prepare("INSERT INTO users (telegram_id, username) VALUES (?, ?)");
        $stmt_insert->bind_param("ss", $telegram_id, $username);
        if ($stmt_insert->execute()) {
            $_SESSION['user_id'] = $stmt_insert->insert_id;
            redirect('dashboard.php');
        } else {
            echo "<script>alert('Registration failed: " . $conn->error . "');</script>";
        }
        $stmt_insert->close();
    }
    $stmt->close();
}

include 'includes/header.php';
?>

<div class="container flex flex-col items-center justify-center min-h-[calc(100vh-10rem)] py-12">
    <div class="form-card p-8 rounded-xl shadow-xl text-center max-w-lg w-full">
        <h1 class="text-4xl font-bold mb-6 text-purple-300">Welcome to LearnX!</h1>
        <p class="text-lg mb-8 text-purple-100">Learn programming, earn points, and unlock premium content.</p>

        <!-- Telegram Login Button -->
        <script async src="https://telegram.org/js/telegram-widget.js?22"
                data-telegram-login="YOUR_BOT_USERNAME"
                data-size="large"
                data-auth-url="https://yourdomain.com/index.php"
                data-request-access="write"></script>
        <p class="text-sm text-gray-400 mt-4">
            (Replace 'YOUR_BOT_USERNAME' and 'https://yourdomain.com/index.php' with your actual Telegram bot username and callback URL)
        </p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
